/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Basic;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author C13
 */
public class Con_JDBC {
        public static Connection getDBConnection() {
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "123");
        } catch (Exception e) {
        }
        return con;
    }
    
}
