-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema test
--

CREATE DATABASE IF NOT EXISTS test;
USE test;

--
-- Definition of table `acc_admin`
--

DROP TABLE IF EXISTS `acc_admin`;
CREATE TABLE `acc_admin` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acc_admin`
--

/*!40000 ALTER TABLE `acc_admin` DISABLE KEYS */;
INSERT INTO `acc_admin` (`id`,`userid`,`password`) VALUES 
 (1,'admin','admin123'),
 (2,'nur','nur123');
/*!40000 ALTER TABLE `acc_admin` ENABLE KEYS */;


--
-- Definition of table `anual_cost`
--

DROP TABLE IF EXISTS `anual_cost`;
CREATE TABLE `anual_cost` (
  `sl` int(10) unsigned NOT NULL auto_increment,
  `year` varchar(45) NOT NULL,
  `emp_cost` varchar(45) default NULL,
  `teach_cost` varchar(45) default NULL,
  `ellect_bill` varchar(45) default NULL,
  `snacks_bill` varchar(45) default NULL,
  `office_bill` varchar(45) default NULL,
  `paper_bill` varchar(45) default NULL,
  `water_bill` varchar(45) default NULL,
  `date` varchar(45) NOT NULL,
  `total_cost` varchar(45) NOT NULL,
  PRIMARY KEY  (`sl`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `anual_cost`
--

/*!40000 ALTER TABLE `anual_cost` DISABLE KEYS */;
INSERT INTO `anual_cost` (`sl`,`year`,`emp_cost`,`teach_cost`,`ellect_bill`,`snacks_bill`,`office_bill`,`paper_bill`,`water_bill`,`date`,`total_cost`) VALUES 
 (1,'2019','44000','130000','8300','4000','1200','1200','9000','6-12-2019','196750'),
 (2,'2019','44000','130000','8300','4000','1200','1200','9000','16-12-2019','196750');
/*!40000 ALTER TABLE `anual_cost` ENABLE KEYS */;


--
-- Definition of table `author`
--

DROP TABLE IF EXISTS `author`;
CREATE TABLE `author` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `author`
--

/*!40000 ALTER TABLE `author` DISABLE KEYS */;
INSERT INTO `author` (`id`,`name`,`address`) VALUES 
 (1,'B','dhaka'),
 (2,'A','sylhet'),
 (3,'shsafd','dfdf'),
 (4,'nur','Dinajpur'),
 (5,'Iftikhar','Gajpur'),
 (6,'Akash','dhaka'),
 (7,'Bikash','Dhaka'),
 (8,'A','sylhet'),
 (9,'Arif','Comilla');
/*!40000 ALTER TABLE `author` ENABLE KEYS */;


--
-- Definition of table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `sl_no` int(10) unsigned NOT NULL auto_increment,
  `category_name` varchar(45) default NULL,
  PRIMARY KEY  (`sl_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;


--
-- Definition of table `daily_cost`
--

DROP TABLE IF EXISTS `daily_cost`;
CREATE TABLE `daily_cost` (
  `sl` int(10) unsigned NOT NULL auto_increment,
  `snacks_bill` varchar(45) default NULL,
  `office_cost` varchar(45) default NULL,
  `date` varchar(45) NOT NULL,
  `year` varchar(45) NOT NULL,
  `month` varchar(45) NOT NULL,
  PRIMARY KEY  (`sl`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daily_cost`
--

/*!40000 ALTER TABLE `daily_cost` DISABLE KEYS */;
INSERT INTO `daily_cost` (`sl`,`snacks_bill`,`office_cost`,`date`,`year`,`month`) VALUES 
 (1,'150','200','5-12-2019','2019','December'),
 (2,'200','200','5-12-2019','2029','December'),
 (3,'170','250','5-12-2019','2019','December'),
 (4,'300','250','5-12-2019','2019','November'),
 (5,'300','250','5','2019','--Select Month--'),
 (6,'600','1000','24','2019','December');
/*!40000 ALTER TABLE `daily_cost` ENABLE KEYS */;


--
-- Definition of table `emp`
--

DROP TABLE IF EXISTS `emp`;
CREATE TABLE `emp` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `salary` double NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp`
--

/*!40000 ALTER TABLE `emp` DISABLE KEYS */;
INSERT INTO `emp` (`id`,`name`,`city`,`salary`) VALUES 
 (1,'nur','dhaka',5000);
/*!40000 ALTER TABLE `emp` ENABLE KEYS */;


--
-- Definition of table `employees_payment_table`
--

DROP TABLE IF EXISTS `employees_payment_table`;
CREATE TABLE `employees_payment_table` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `cont_no` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `post` varchar(45) NOT NULL,
  `salary` varchar(45) NOT NULL,
  `year` varchar(45) NOT NULL,
  `month` varchar(45) NOT NULL,
  `pay_option` varchar(45) NOT NULL,
  `date` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees_payment_table`
--

/*!40000 ALTER TABLE `employees_payment_table` DISABLE KEYS */;
INSERT INTO `employees_payment_table` (`id`,`name`,`cont_no`,`gender`,`post`,`salary`,`year`,`month`,`pay_option`,`date`) VALUES 
 (2001,'Nur','0183563465','Male','Guardsman','10000','2019','September','Paid','2-12-2019'),
 (2001,'Nur','01754636476','Male','Office Clark','12000','2019','November','Paid','2-12-2019'),
 (201,'gfd','01787987901','Male','Bell Ringer','12000','2019','November','Paid','4-12-2019'),
 (202,'cvbgc','01656786569','Male','Sweeper','10000','2019','October','Paid','5-12-2019'),
 (202,'cvbgc','01656786569','Male','Sweeper','10000','2019','December','Paid','16-12-2019');
/*!40000 ALTER TABLE `employees_payment_table` ENABLE KEYS */;


--
-- Definition of table `employees_record`
--

DROP TABLE IF EXISTS `employees_record`;
CREATE TABLE `employees_record` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `cont_no` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `birth_date` varchar(45) NOT NULL,
  `post` varchar(45) NOT NULL,
  `app_date` varchar(45) NOT NULL,
  `salary` varchar(45) NOT NULL,
  `duty_time` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees_record`
--

/*!40000 ALTER TABLE `employees_record` DISABLE KEYS */;
INSERT INTO `employees_record` (`id`,`name`,`cont_no`,`gender`,`address`,`birth_date`,`post`,`app_date`,`salary`,`duty_time`) VALUES 
 (202,'cvbgc','01656786569','male','dgdrhttu','2004-12-05','Sweeper','2019-12-01','10000','9:00am to 5:00pm'),
 (203,'fdsg','01756578776','male','hfgujgh','Dec 1, 2002','Office Clark','Dec 1, 2019','12000','6:00am to 2:00pm'),
 (2001,'Nur','01754636476','Male','mohakhali','11-11-2019','Office Clark','10-10-2019','12000','8:00am to 5:00pm'),
 (2002,'cvbgc','01656786569','male','dgdrhttu','1999-12-05','Sweeper','2019-12-01','10000','9:00am to 5:00pm');
/*!40000 ALTER TABLE `employees_record` ENABLE KEYS */;


--
-- Definition of table `exam_record`
--

DROP TABLE IF EXISTS `exam_record`;
CREATE TABLE `exam_record` (
  `sl` int(10) unsigned NOT NULL auto_increment,
  `id` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `cont_no` varchar(45) default NULL,
  `gender` varchar(45) NOT NULL,
  `class` varchar(45) NOT NULL,
  `exam_name` varchar(45) NOT NULL,
  `year` varchar(45) default NULL,
  `month` varchar(45) default NULL,
  `pay_option` varchar(45) NOT NULL,
  `date` varchar(45) NOT NULL,
  `amount` varchar(45) NOT NULL,
  PRIMARY KEY  (`sl`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_record`
--

/*!40000 ALTER TABLE `exam_record` DISABLE KEYS */;
INSERT INTO `exam_record` (`sl`,`id`,`name`,`cont_no`,`gender`,`class`,`exam_name`,`year`,`month`,`pay_option`,`date`,`amount`) VALUES 
 (1,'3','tgt','01835748','Female','Six','Anual Exam','2019','November','Paid','6-12-2019','300'),
 (2,'1','Bishas','01397654882','Male','Eight','Anual Exam','2019','November','Paid','7-12-2019','400'),
 (3,'2','Nur','01744227756','Male','Five','Half yearly Exam','2019','October','Paid','11-12-2019','400');
/*!40000 ALTER TABLE `exam_record` ENABLE KEYS */;


--
-- Definition of table `income_calculate`
--

DROP TABLE IF EXISTS `income_calculate`;
CREATE TABLE `income_calculate` (
  `sl` int(10) unsigned NOT NULL auto_increment,
  `year` varchar(45) NOT NULL,
  `month` varchar(45) NOT NULL,
  `total_m_fee` varchar(45) default NULL,
  `exam_fee` varchar(45) default NULL,
  `admit_fee` varchar(45) default NULL,
  `other_income` varchar(45) default NULL,
  `total_income` varchar(45) NOT NULL,
  PRIMARY KEY  (`sl`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `income_calculate`
--

/*!40000 ALTER TABLE `income_calculate` DISABLE KEYS */;
INSERT INTO `income_calculate` (`sl`,`year`,`month`,`total_m_fee`,`exam_fee`,`admit_fee`,`other_income`,`total_income`) VALUES 
 (1,'2019','November','1200.0','300.0','25500.0','59300.0','86300.0'),
 (2,'2019','December','700','0','45500','248700',''),
 (3,'2019','December','700.0','0.0','45500.0','356700.0','402900.0');
/*!40000 ALTER TABLE `income_calculate` ENABLE KEYS */;


--
-- Definition of table `monthly_cost`
--

DROP TABLE IF EXISTS `monthly_cost`;
CREATE TABLE `monthly_cost` (
  `sl` int(10) unsigned NOT NULL auto_increment,
  `year` varchar(45) NOT NULL,
  `month` varchar(45) NOT NULL,
  `emp_cost` varchar(45) default NULL,
  `teach_cost` varchar(45) default NULL,
  `illect_bill` varchar(45) default NULL,
  `snacks_bill` varchar(45) default NULL,
  `office_bill` varchar(45) default NULL,
  `paper_bill` varchar(45) default NULL,
  `water_bill` varchar(45) default NULL,
  `date` varchar(45) NOT NULL,
  `total_m_cost` varchar(45) NOT NULL,
  PRIMARY KEY  (`sl`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `monthly_cost`
--

/*!40000 ALTER TABLE `monthly_cost` DISABLE KEYS */;
INSERT INTO `monthly_cost` (`sl`,`year`,`month`,`emp_cost`,`teach_cost`,`illect_bill`,`snacks_bill`,`office_bill`,`paper_bill`,`water_bill`,`date`,`total_m_cost`) VALUES 
 (1,'2019','November','24000.0','64000.0','300.0','4000.0','400.0','400.0','3000.0','6-12-2019','95950.0'),
 (2,'2019','October','10000.0','44000.0','4000.0','0.0','0.0','400.0','3000.0','6-12-2019','61400.0'),
 (3,'2019','September','10000.0','22000.0','4000.0','0.0','0.0','400.0','3000.0','6-12-2019','39400.0');
/*!40000 ALTER TABLE `monthly_cost` ENABLE KEYS */;


--
-- Definition of table `other_income_table`
--

DROP TABLE IF EXISTS `other_income_table`;
CREATE TABLE `other_income_table` (
  `sl` int(10) unsigned NOT NULL auto_increment,
  `year` varchar(45) NOT NULL,
  `month` varchar(45) NOT NULL,
  `paper_inc` varchar(45) default NULL,
  `product_inc` varchar(45) default NULL,
  `gift` varchar(45) default NULL,
  `other_inc` varchar(45) default NULL,
  `total_inc` varchar(45) default NULL,
  `date` varchar(45) NOT NULL,
  PRIMARY KEY  (`sl`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `other_income_table`
--

/*!40000 ALTER TABLE `other_income_table` DISABLE KEYS */;
INSERT INTO `other_income_table` (`sl`,`year`,`month`,`paper_inc`,`product_inc`,`gift`,`other_inc`,`total_inc`,`date`) VALUES 
 (1,'2019','November','300.0','2000.0','30000.0','2000.0','34300.0','7-12-2019'),
 (2,'2019','December','400.0','4000.0','200000.0','10000.0','214400.0','16-12-2019'),
 (3,'2019','December','4000.0','4000.0','100000.0','0.0','108000.0','22-12-2019'),
 (4,'2019','October','0.0','0.0','20000.0','0.0','20000.0','22-12-2019'),
 (5,'2019','November','3000.0','24000.0','30000.0','0.0','57000.0','24-12-2019');
/*!40000 ALTER TABLE `other_income_table` ENABLE KEYS */;


--
-- Definition of table `stu`
--

DROP TABLE IF EXISTS `stu`;
CREATE TABLE `stu` (
  `id` int(11) NOT NULL auto_increment,
  `course` tinyblob,
  `dob` varchar(255) default NULL,
  `gender` varchar(255) default NULL,
  `location` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stu`
--

/*!40000 ALTER TABLE `stu` DISABLE KEYS */;
INSERT INTO `stu` (`id`,`course`,`dob`,`gender`,`location`,`name`) VALUES 
 (1,0xACED0005757200135B4C6A6176612E6C616E672E537472696E673BADD256E7E91D7B470200007870000000017400044A617661,'2010/02/1','Male','Dhaka','ert'),
 (2,0xACED0005757200135B4C6A6176612E6C616E672E537472696E673BADD256E7E91D7B47020000787000000001740003577370,'2010/02/1','Female','Dhaka','ert');
/*!40000 ALTER TABLE `stu` ENABLE KEYS */;


--
-- Definition of table `student_information`
--

DROP TABLE IF EXISTS `student_information`;
CREATE TABLE `student_information` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `f_name` varchar(45) NOT NULL,
  `m_name` varchar(45) NOT NULL,
  `contact_no` varchar(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` varchar(45) NOT NULL,
  `blood_group` varchar(5) default NULL,
  `class` varchar(10) NOT NULL,
  `email` varchar(45) default NULL,
  `date` varchar(20) default NULL,
  `admit_fee` varchar(45) default NULL,
  `year` varchar(45) NOT NULL,
  `c_date` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_information`
--

/*!40000 ALTER TABLE `student_information` DISABLE KEYS */;
INSERT INTO `student_information` (`id`,`name`,`f_name`,`m_name`,`contact_no`,`gender`,`address`,`blood_group`,`class`,`email`,`date`,`admit_fee`,`year`,`c_date`) VALUES 
 (1,'Bishas','Bishoo','Dipali','01397654882','male','Dhaka','b+','Eight','bishas82@gmail.com','05-11-1996','5000','2019','01-12-2019'),
 (2,'Nur','Sayed Ali','Zorina','01744227782','male','Mohakhali','A+','Five','asiquee@gmail.com','04-12-1993','4500','2019','null'),
 (3,'tgt','ftyty','Fatema','0645343','Female','sdfsdrs','A+','Six','dfgdf@.co','09-11-1975','4500','2019','01-12-2019'),
 (6,'Moon','hggh','vfdggf','01734237776','male','fgdfgds','A-','Ten','dagfjau@jsdk.co','09-11-1975','6000','2019','01-12-2019'),
 (8,'dj Faruk','Dishan','Rebeka','01843767348','male','dgffjghdfh','B+','Ten','hsfjhdsh@gmail.com','1996-12-08','6000','2019','01-12-2019'),
 (10,'sdfg','vdxfgbx','fdsgg','01734657867','male','dfvxgbc','B-','Nine','fgjfghj @gd.co','2004-12-06','10000','2019','null'),
 (11,'Nur','Sayed Ali','Zorina','0174422787','male','Mohakhali','A+','Five','asiquee@gmail.com','04-12-1993','4500','2019','null'),
 (12,'Nur','frrtt','etrdh','0177436563','male','dfghfgh','A-','Nine','hfkh@fjkd.co','2005-12-04','5000','2019','null');
/*!40000 ALTER TABLE `student_information` ENABLE KEYS */;


--
-- Definition of table `student_payment_table`
--

DROP TABLE IF EXISTS `student_payment_table`;
CREATE TABLE `student_payment_table` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `contact_no` varchar(45) NOT NULL,
  `class` varchar(45) NOT NULL,
  `payment_year` varchar(45) NOT NULL,
  `month_from` varchar(45) NOT NULL,
  `month_to` varchar(45) NOT NULL,
  `total_amount` varchar(45) NOT NULL,
  `pay_date` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_payment_table`
--

/*!40000 ALTER TABLE `student_payment_table` DISABLE KEYS */;
INSERT INTO `student_payment_table` (`id`,`name`,`contact_no`,`class`,`payment_year`,`month_from`,`month_to`,`total_amount`,`pay_date`) VALUES 
 (2,'Nur','01744227782','Five','2019','October','November','1200','2-12-2019'),
 (2,'Nur','01744227756','Five','2019','December','December','700','16-12-2019'),
 (6,'Moon','01734237776','Ten','2019','October','December','3600','24-12-2019');
/*!40000 ALTER TABLE `student_payment_table` ENABLE KEYS */;


--
-- Definition of table `teachers_payment_table`
--

DROP TABLE IF EXISTS `teachers_payment_table`;
CREATE TABLE `teachers_payment_table` (
  `sl` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `subject` varchar(45) NOT NULL,
  `payment_amount` varchar(45) NOT NULL,
  `year` varchar(45) NOT NULL,
  `month` varchar(45) NOT NULL,
  `payment_option` varchar(45) NOT NULL,
  `payment_date` varchar(45) NOT NULL,
  `id` varchar(45) NOT NULL,
  PRIMARY KEY  USING BTREE (`sl`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers_payment_table`
--

/*!40000 ALTER TABLE `teachers_payment_table` DISABLE KEYS */;
INSERT INTO `teachers_payment_table` (`sl`,`name`,`subject`,`payment_amount`,`year`,`month`,`payment_option`,`payment_date`,`id`) VALUES 
 (1,'Noyon','Bangla','20000','2019','November','Paid','12-11-2019',''),
 (2,'noyon','Bangla','22000','2019','November','Paid','27-11-2019','1001'),
 (3,'Akash','History','22000','2019','November','Paid','27-11-2019','1003'),
 (4,'Akash','History','22000','2019','October','Paid','27-11-2019','1003'),
 (5,'noyon','Bangla','22000','2019','October','Paid','27-11-2019','1001'),
 (6,'Akash','History','22000','2019','September','Paid','27-11-2019','1003'),
 (7,'noyon','Bangla','22000','2019','August','Paid','28-11-2019','1001'),
 (8,'dfgg','Islam','15000','2019','December','Paid','16-12-2019','200');
/*!40000 ALTER TABLE `teachers_payment_table` ENABLE KEYS */;


--
-- Definition of table `teachers_table`
--

DROP TABLE IF EXISTS `teachers_table`;
CREATE TABLE `teachers_table` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `cont_no` varchar(45) NOT NULL,
  `f_name` varchar(45) default NULL,
  `f_cont_no` varchar(45) default NULL,
  `m_name` varchar(45) default NULL,
  `m_cont_no` varchar(45) default NULL,
  `gender` varchar(45) NOT NULL,
  `m_status` varchar(45) default NULL,
  `b_group` varchar(45) default NULL,
  `b_date` varchar(45) NOT NULL,
  `subject` varchar(45) NOT NULL,
  `post` varchar(45) NOT NULL,
  `app_date` varchar(45) NOT NULL,
  `salary` varchar(45) NOT NULL,
  `email` varchar(45) default NULL,
  `address` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers_table`
--

/*!40000 ALTER TABLE `teachers_table` DISABLE KEYS */;
INSERT INTO `teachers_table` (`id`,`name`,`cont_no`,`f_name`,`f_cont_no`,`m_name`,`m_cont_no`,`gender`,`m_status`,`b_group`,`b_date`,`subject`,`post`,`app_date`,`salary`,`email`,`address`) VALUES 
 (200,'dfgg','0174546765','gfd','0145676879','fhfghg','0134567786','male','Unmarried','fghgfj','1997-12-09','Islam','Assistance Teacher','2019-12-01','15000','dtfyts@fghg.co','erty'),
 (201,'fghdf','0154689879','fhgfn','0108709976','gfmjfh','0145767889','male','Unmarried','B-','2003-12-02','Computer','Assistant Teacher','2019-12-01','13000','fsdgf@fdh.co','gfhfvc ');
/*!40000 ALTER TABLE `teachers_table` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
